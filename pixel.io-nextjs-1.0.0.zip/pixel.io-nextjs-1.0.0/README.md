# Pixel.io - Digital Agency Website Template

#### Preview

 - [Demo](https://themewagon.github.io/pixel.io-nextjs/)

#### Download
 - [Download from ThemeWagon](https://themewagon.com/themes/pixel.io-nextjs/)

## Getting Started

1. Clone Repository
```
git clone https://github.com/themewagon/pixel.io-nextjs.git
```
2. Install Dependencies
```
npm i
```
3. Run the development server:

```bash
npm run dev
# or
yarn dev
# or
pnpm dev
# or
bun dev
```

## Author 
```
Design and code is completely written by PrebuiltUI and development team. 
```

## License

 - Design and Code is Copyright &copy; <a href="https://prebuiltui.com/tailwind-templates?ref=pixel-forge" target="_blank">prebuiltUI</a>
 - Licensed cover under [MIT]
 - Distributed by <a href="https://themewagon.com" target="_blank">ThemeWagon</a>
